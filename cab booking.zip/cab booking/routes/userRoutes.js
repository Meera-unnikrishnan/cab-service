const express = require('express');
// const controller = require('../controller/userControllers');
// const controllers=require('../controller/accountsController')
// const router = express.Router();

// module.exports = router;


