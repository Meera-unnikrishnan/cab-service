const express = require('express');
const controller = require('../controller/driverController');

const router = express.Router();

router.get('/driverIndex',controller.driver);
router.get('/driverRegister',controller.driverReg);
router.post('/driverRegister',controller.driverReg);



module.exports = router;
