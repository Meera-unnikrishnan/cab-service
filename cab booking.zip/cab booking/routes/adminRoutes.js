const express = require('express');
const controller = require('../controller/adminController');
const { route } = require('./accountsRoutes');

const router = express.Router();

// router.get('/admin', controller.viewUser);
// router.post('/admin', controller.viewUser);
// router.get('/register', controller.register);
// router.post('/register', controller.registerPost);
// router.get('/index',controller.home);

// router.get('/admin',controller.showUser);
router.get('/fetchData',controller.fetchData);
module.exports = router;

// router.get('/', controller.index);
router.get('/usercreate', controller.usercreate);
router.post('/usercreate', controller.usercreatePost);
router.get('/user-update/:id', controller.userupdate);
router.post('/user-update/:id', controller.userupdatePost);
router.get('/userdelete/:id', controller.userdelete);