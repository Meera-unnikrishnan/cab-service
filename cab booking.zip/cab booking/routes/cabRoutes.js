const express = require('express');
const controllers = require('../controller/cabcontroller');
const router = express.Router();
router.get('/booking',controllers.booking);
router.post('/booking',controllers.bookingPost);

module.exports = router;