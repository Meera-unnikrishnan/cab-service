const User = require('../model/user');

// module.exports.showUser = (req, res, next) => {
//     User.findAll().then(User => {
//             res.render('admin', {
//                 data: User
//             });
        
//             res.json(User)
//         })
//     }


   
    module.exports.fetchData = (req, res, next) => {
        let array = []
        User.findAll().then(User => {
                console.log(User)
               User.forEach((i)=>{   
                array.push(i.dataValues)         
               })


               console.log("line 21")
               res.send({data:array})
                // res.json(User)
               
            })
        }
module.exports.usercreate = (req, res, next) => {
    res.render('usercreate');
}
module.exports.usercreatePost = (req, res, next) => {
    User.create({
        fullName: req.body.fullName,
        address: req.body.address,
        gender: req.body.inlineRadioOptions,
        state: req.body.state,
        city: req.body.city,
        idproof: req.body.idproof,
        phone: req.body.phone,
        email: req.body.email,
        pass_word: req.body.pass
        })
        .then(userFromDb => {
            res.redirect("/admin");
        })
}

module.exports.userupdate = async(req, res, next) => {
    User.findByPk(req.params.id)
        .then(userFromDb => {
            console.log("line 53")
            console.log(JSON.stringify(userFromDb));
            res.render('user-update', {
                data: JSON.parse(JSON.stringify(userFromDb))
            });
        });
}

module.exports.userupdatePost = (req, res, next) => {
    User.findByPk(req.params.id)
        .then(user => {
            User.update({
                fullName: req.body.fullName,
                address: req.body.address,
                gender: req.body.inlineRadioOptions,
                state: req.body.state,
                city: req.body.city,
                idproof: req.body.idproof,
                phone: req.body.phone,
                email: req.body.email,
                pass_word: req.body.pass
                   
                }, {
                    where: {
                        id: req.params.id
                    }
                })
                .then(count => {
                    res.redirect('/admin');
                });
        });
}

module.exports.userdelete = async (req, res, next) => {
    let id = req.params.id;
    let userFromDb = await User.findByPk(id);
    console.log("finding")
    if (userFromDb != null) {
        await User.destroy({
            where: {
                id: id
            }
           
        });
        console.log("deleted");
        res.redirect("/admin");
    }
}