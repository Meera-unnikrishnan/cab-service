const CabBook = require('../model/cabBooking');
const { body, validationResult } = require('express-validator');

module.exports.booking= (req, res, next)=>{
    res.render('booking');
}

module.exports.bookingPost = async (req, res, next)=>{
    console.log(req.body);

    await CabBook.create({
          fullName:req.body.Name,
          phone:req.body.phone,
          email: req.body.email,
          cab_type:req.body.cabtype,
          booking_date:req.body.date,
          booking_time:req.body.Time,
          pickup_loc:req.body.pLocation,
          dropoff_loc: req.body.dLocation,
          Num_passenger:req.body.passnum, 
          direction:req.body.direction
      }).then((user) => {
        res.redirect("/index");
      });
  
      
  }