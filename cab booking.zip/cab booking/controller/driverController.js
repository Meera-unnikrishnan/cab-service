const Driver = require('../model/driver');
const { body, validationResult } = require('express-validator');
module.exports.driver = (req, res, next)=>{
    res.render('driverIndex');
}
module.exports.driverReg= (req, res, next)=>{
    res.render('driverRegister');
}
module.exports.driverLogin= (req, res, next)=>{
    res.render('driverLogin');
}
