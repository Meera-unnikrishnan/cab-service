const User = require('../model/user');
const { body, validationResult } = require('express-validator');



module.exports.login = (req, res, next)=>{
    res.render('login');
}

function showData(arg,req,res){
    res.redirect('/userIndex')
    module.exports.data = arg;
}
module.exports.showAdmin = (req, res, next) => {

    res.render('admin');
}
module.exports.loginPost = async (req, res, next)=>{
    const {email, password} = req.body;

    // console.log(email)
    // console.log(password)
    if(email=="admin@gmail.com" && password=="admin@123"){
        console.log("user found");
        res.redirect('/admin');
    }


    const userFromDb = await User.findOne({
        where: {email: email, pass_word: password},
    });
    
    if(userFromDb == null){
       return res.render('login', {message: 'No user with this email or password was found.'})
    } 
     showData(JSON.stringify(userFromDb),req,res)
     res.redirect('/userIndex');
}

module.exports.userhome = (req,res,next) =>{
    res.render('userIndex');
}

module.exports.userhomeupdate = (req,res,next)=>{
    User.findByPk(req.params.id)
    .then(userFromDb => {
        res.render('user-update',{
            data : userFromDb
        })
    })
}

module.exports.userhomeupdatePost = async (req,res,next)=>{
    await User.update(
        {
      fullName: req.body.fullName,
      address: req.body.address,
      gender: req.body.inlineRadioOptions,
      state: req.body.state,
      city: req.body.city,
      idproof: req.body.idproof,
      phone: req.body.phone,
      email: req.body.email,
      pass_word: req.body.pass,
        },
        {
            where: {
                id: req.params.id
            }
        }
    )
    res.redirect('/userIndex')

}

module.exports.userhomedelete = async(req,res,next) => {
    let id = req.params.id;
    let userFromDb = await User.findByPk(id);
    if( userFromDb != null)
    {
        await User.destroy(
            {
                where : 
                {
                    id : id

                }
            }
        );
        res.redirect('/index');
    }
}
   


module.exports.home = (req, res, next)=>{
    res.render('index');
}



module.exports.register = (req, res, next)=>{
    res.render('register');
}

module.exports.registerPost = async (req, res, next)=>{
    console.log(req.body);
    const {fullName,address,gender,state,city,idproof,phone,email,pass_word} = req.body;
    console.log(fullName)
    let existingUser = await User.findOne({
        where: {
            email: email
        }
    });

    if(existingUser){
        console.log("already registered")
        return res.render('register', {message: 'ALREADY REGISTERED..PLEASE LOGIN'});
    }

    await User.create({
      fullName: req.body.fullName,
      address: req.body.address,
      gender: req.body.inlineRadioOptions,
      state: req.body.state,
      city: req.body.city,
      idproof: req.body.idproof,
      phone: req.body.phone,
      email: req.body.email,
      pass_word: req.body.pass,
    }).then((user) => {
      res.redirect("/login");
    });

    
}
