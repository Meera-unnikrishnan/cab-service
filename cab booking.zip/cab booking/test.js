let data =[
     {
      dataValues: {
        id: 1,
        fullName: 'meera.unnikrishnan',
        address: 'aaaaaaaaaa',
        gender: 'female',
        state: '2',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 12345678,
        email: 'meeraunnikrishnan25@gmail.com',
        pass_word: 'meera123456',
        createdAt: 2022-11-24T06:58:38.000Z,
        updatedAt: 2022-11-24T06:58:38.000Z
      },
      _previousDataValues: {
        id: 1,
        fullName: 'meera.unnikrishnan',
        address: 'aaaaaaaaaa',
        gender: 'female',
        state: '2',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 12345678,
        email: 'meeraunnikrishnan25@gmail.com',
        pass_word: 'meera123456',
        createdAt: 2022-11-24T06:58:38.000Z,
        updatedAt: 2022-11-24T06:58:38.000Z
      },
      uniqno: 1,
      _changed: Set(0) {},
      _options: {
        isNewRecord: false,
        _schema: null,
        _schemaDelimiter: '',
        raw: true,
        attributes: [Array]
      },
      isNewRecord: false
    },
    user {
      dataValues: {
        id: 2,
        fullName: 'meera unni',
        address: 'vvvvvvvvvv',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98989898,
        email: 'me@gmail.com',
        pass_word: '98fgsfhj23',
        createdAt: 2022-11-25T07:15:00.000Z,
        updatedAt: 2022-11-25T07:15:00.000Z
      },
      _previousDataValues: {
        id: 2,
        fullName: 'meera unni',
        address: 'vvvvvvvvvv',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98989898,
        email: 'me@gmail.com',
        pass_word: '98fgsfhj23',
        createdAt: 2022-11-25T07:15:00.000Z,
        updatedAt: 2022-11-25T07:15:00.000Z
      },
      uniqno: 1,
      _changed: Set(0) {},
      _options: {
        isNewRecord: false,
        _schema: null,
        _schemaDelimiter: '',
        raw: true,
        attributes: [Array]
      },
      isNewRecord: false
    },
    user {
      dataValues: {
        id: 3,
        fullName: 'arsha s',
        address: 'aaaaaaaaaa',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98765432,
        email: 'arsha@gmail.com',
        pass_word: '98765asdfg',
        createdAt: 2022-11-25T09:10:56.000Z,
        updatedAt: 2022-11-25T09:10:56.000Z
      },
      _previousDataValues: {
        id: 3,
        fullName: 'arsha s',
        address: 'aaaaaaaaaa',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98765432,
        email: 'arsha@gmail.com',
        pass_word: '98765asdfg',
        createdAt: 2022-11-25T09:10:56.000Z,
        updatedAt: 2022-11-25T09:10:56.000Z
      },
      uniqno: 1,
      _changed: Set(0) {},
      _options: {
        isNewRecord: false,
        _schema: null,
        _schemaDelimiter: '',
        raw: true,
        attributes: [Array]
      },
      isNewRecord: false
    },
    user {
      dataValues: {
        id: 4,
        fullName: 'admin',
        address: 'aaaa',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98989778,
        email: 'admin@gmail.com',
        pass_word: 'admin@123',
        createdAt: 2022-11-28T00:00:00.000Z,
        updatedAt: 2022-11-28T00:00:00.000Z
      },
      _previousDataValues: {
        id: 4,
        fullName: 'admin',
        address: 'aaaa',
        gender: 'female',
        state: 'kerala',
        city: 'kothamangalam',
        idproof: 'votersid',
        phone: 98989778,
        email: 'admin@gmail.com',
        pass_word: 'admin@123',
        createdAt: 2022-11-28T00:00:00.000Z,
        updatedAt: 2022-11-28T00:00:00.000Z
      },
      uniqno: 1,
      _changed: Set(0) {},
      _options: {
        isNewRecord: false,
        _schema: null,
        _schemaDelimiter: '',
        raw: true,
        attributes: [Array]
      },
      isNewRecord: false
    }
  ]