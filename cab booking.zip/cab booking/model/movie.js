// const sequelize = require('./db');
// const {DataTypes} = require('sequelize');

// const user_login = sequelize.define('user_login',{
//     user_id: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     email {
//         type: DataTypes.STRING(70),
//         allowNull: false,
//     },
//     password {
//         type: DataTypes.DATEONLY,
//         allowNull: false
//     },
//     summary: {
//         type: DataTypes.STRING(250),
//         allowNull: true,
//     },
//     director: {
//         type: DataTypes.STRING(50),
//         allowNull: false
//     }
// });

// module.exports = Movie;