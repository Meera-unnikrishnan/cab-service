// const movie = require('./movie');
const user = require('./user');
const cab = require('./cab');
const cabBooking = require('./cabBooking');
const driver = require('./driver');
driver.sync({alter:true});
user.sync({alter: true});
cab.sync({alter:true});
cabBooking.sync({alter:true});

